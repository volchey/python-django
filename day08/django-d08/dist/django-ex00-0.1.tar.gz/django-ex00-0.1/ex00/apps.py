from django.apps import AppConfig


class Ex00Config(AppConfig):
    name = 'ex00'
